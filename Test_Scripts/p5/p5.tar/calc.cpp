#include "dlist.h"
#include "iostream"
#include "string"
using namespace std;

bool plus_stack(Dlist<int> &stack, int &opNum){
    if (opNum<2){
        return false;
    } else{
        int *num1= stack.removeFront();
        int *num2= stack.removeFront();
        int sum=*num1+*num2;
        int *result=new int(sum);
        stack.insertFront(result);
        opNum--;
        delete num1;
        delete num2;
        return true;
    }
}

bool minus_stack(Dlist<int> &stack, int &opNum){
    if (opNum<2){
        return false;
    } else{
        int *num1= stack.removeFront();
        int *num2= stack.removeFront();
        int diff=*num2-*num1;
        int *result=new int(diff);
        stack.insertFront(result);
        opNum--;
        delete num1;
        delete num2;
        return true;
    }
}

bool multi_stack(Dlist<int> &stack, int &opNum){
    if (opNum<2){
        return false;
    } else{
        int *num1= stack.removeFront();
        int *num2= stack.removeFront();
        int product=(*num2)*(*num1);
        int *result=new int(product);
        stack.insertFront(result);
        opNum--;
        delete num1;
        delete num2;
        return true;
    }
}

bool divide_stack(Dlist<int> &stack, int &opNum){
    if (opNum<2){
        return false;
    } else{
        int* num1= stack.removeFront();
        int* num2= stack.removeFront();
        if (*num1==0){
            //error input case 3
            cout<<"Divide by zero\n";
            //oFile<<"Divide by zero\n";
            stack.insertFront(num2);
            stack.insertFront(num1);
        }else{
            int quo=(*num2)/(*num1);
            int *result=new int(quo);
            stack.insertFront(result);
            opNum--;
            delete num1;
            delete num2;
        }
        return true;
    }
}

bool negate_stack(Dlist<int> &stack, int &opNum){
    if (opNum<1){
        return false;
    }else{
        int *num= stack.removeFront();
        int neg=- *num;
        int *result=new int (neg);
        stack.insertFront(result);
        delete num;
        return true;
    }
}

bool duplicate_stack(Dlist<int> &stack, int &opNum){
    if (opNum<1){
        return false;
    }else{
        int *dul= stack.removeFront();
        int *result1=new int(*dul);
        int *result2=new int(*dul);
        stack.insertFront(result1);
        stack.insertFront(result2);
        opNum++;
        delete dul;
        return true;
    }
}

bool reverse_stack(Dlist<int> &stack, int &opNum){
    if (opNum<2){
        return false;
    }else{
        int *num1= stack.removeFront();
        int *num2= stack.removeFront();
        stack.insertFront(num1);
        stack.insertFront(num2);
        return true;
    }
}

bool print_stack(Dlist<int> &stack, int &opNum){
    if (opNum<1){
        return false;
    }else{
        int *top=stack.removeFront();
        cout<<*top<<endl;
        //oFile<<*top<<endl;
        stack.insertFront(top);
        return true;
    }
}

void clear_stack(Dlist<int> &stack, int &opNum){
    while (!stack.isEmpty()){stack.removeFront();}
    opNum=0;
}

void print_all_stack(Dlist<int> &stack){
    Dlist<int> stack_cp;
    stack_cp.operator=(stack);
    while (!stack_cp.isEmpty()){
        int *top=stack_cp.removeFront();
        cout<<*top<<" ";
        //oFile<<*top<<" ";
        delete top;
    }
    cout<<endl;
    //oFile<<endl;
}

bool isValid(const string &command) {
    bool isOp = false;
    bool isValidInt = false;
    if (command == "+" || command == "-" || command == "*" || command == "/" || command == "n" || command == "d" ||
        command == "r" ||
        command == "p" || command == "c" || command == "a") { isOp = true; }
    else {
        bool isEffDigit = false;
        bool isDigit = true;
        int digitNum = 0;
        for (auto it = command.cbegin(); it != command.end(); ++it) {
            if (it == command.cbegin() && *it == '-') continue;
            if (*it <= '9' && *it >= '0') {
                if (!isEffDigit && *it != '0') { isEffDigit = true; }
                if (isEffDigit) { digitNum++; }
            } else {
                isDigit = false;
                break;
            }
        }
        if (digitNum <= 9 && isDigit) {
            isValidInt = true;
        }
    }
    return isOp || isValidInt;
}


//judge whether the command is valid (exclude quit command) and store the valid command into the stack
bool isQuit(const string& command){
    if (command=="q"){return true;}
    else{return false;}
}

//void fileEmpty(const string fileName)
//{
//    fstream file(fileName, ios::out);
//}

int main(){
//    //fileEmpty("answer");
//    ofstream oFile;
//    oFile.open("answer");


    Dlist<int> stack;
    string command;
    int opNum=0; //count the op number
    while (cin>>command){
        //the quit command
        if (isQuit(command)){return 0;}
        // error input case1
        if (!isValid(command)){cout<<"Bad input\n"; continue; }
        else{
            bool isOpNum= true;
            if (command =="+"){isOpNum=plus_stack(stack,opNum);}
            else if (command=="-"){isOpNum=minus_stack(stack,opNum);}
            else if (command=="*"){ isOpNum= multi_stack(stack,opNum);}
            else if (command=="/"){ isOpNum= divide_stack(stack,opNum);}
            else if (command=="n"){ isOpNum= negate_stack(stack,opNum);}
            else if (command=="d"){ isOpNum= duplicate_stack(stack,opNum);}
            else if (command=="r"){ isOpNum= reverse_stack(stack,opNum);}
            else if (command=="p"){ isOpNum= print_stack(stack,opNum);}
            else if (command=="c"){ clear_stack(stack,opNum);}
            else if (command=="a"){ print_all_stack(stack);}
            else {//insert to the stack
                int *pInt=new int(stoi(command));
                stack.insertFront(pInt);
                opNum++;
            }
            //error input case 2
            if (!isOpNum){cout<<"Not enough operands\n";continue;
            }
        }
    }
}

