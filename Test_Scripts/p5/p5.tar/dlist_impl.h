#ifndef P5_DLIST_IMPL_H
#define P5_DLIST_IMPL_H
#include "dlist.h"
//check whether there's a mem
template <class T>
bool Dlist<T>::isEmpty() const {
    if (first== nullptr && last== nullptr)
        return true;
    return false;
}

template <class T>
void Dlist<T>::insertFront(T *op) {
   node *np=new node;
   np->op=op;
   np->next=first;
   np->prev= nullptr;
    if (isEmpty()) {
        first=last=np;
        return;
    }
   first->prev=np;
   first=np;
}

template <class T>
void Dlist<T>::insertBack(T *op) {
    node *np=new node;
    np->op=op;
    np->next= nullptr;
    np->prev=last;
    if (isEmpty()) {
        first=last=np;
        return;
    }
    last->next=np;
    last=np;
}

template <class T>
T *Dlist<T>::removeFront() {
    if (isEmpty()){
        emptyList emptyList;
        throw emptyList;
    }
    node *victim=first;
    T *result=victim->op;
    if (first != last){
        first=victim->next;
        first->prev= nullptr;
    } else first=last= nullptr;
    delete victim;
    return result;
}

template <class T>
T *Dlist<T>::removeBack() {
    if (isEmpty()) {
        emptyList emptyList;
        throw emptyList;
    }
    node *victim=last;
    T *result=victim->op;
    if (first!=last){
        last=victim->prev;
        last->next= nullptr;
    } else first=last= nullptr;
    delete victim;
    return result;
}

template <class T>
void Dlist<T>::removeAll() {
    while (!isEmpty()){
        T *op=removeFront();
        delete op;
    }
}

template <class T>
void Dlist<T>::copyAll(const Dlist<T> &l) {
    node *p=l.first;
    while (p){
        T *op=new T(*p->op);
        insertBack(op);
        p=p->next;
    }
}

template <class T>
Dlist<T>::Dlist(): first(nullptr), last(nullptr) {}

template <class T>
Dlist<T>::Dlist(const Dlist<T> &l): first(nullptr), last(nullptr) {
    copyAll(l);
}

template <class T>
Dlist<T> &Dlist<T>::operator=(const Dlist<T> &l) {
    //ensure that there's no self copy
    if (this != &l){
        //destroy the current list first
        removeAll();
        copyAll(l);
    }
    return *this;
}

template <class T>
Dlist<T>::~Dlist() {
    removeAll();
}


#endif //P5_DLIST_IMPL_H
