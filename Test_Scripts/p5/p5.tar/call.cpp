#include "dlist.h"
#include "dlist_impl.h"
#include "iostream"
#include "string.h"

using namespace std;
struct customer{
    int timeStamp;
    string name;
    string status;
    int duration;
};

bool isComplete(Dlist<customer>* processingList){
    for (int i = 0; i < 4; ++i) {
        if (!processingList[i].isEmpty()){return false;}
    }
    return true;
}
//when all the list is processed


int main (){
    //do some initialization
    Dlist<customer> callList;
    Dlist<customer> list_reg;
    Dlist<customer> list_sil;
    Dlist<customer> list_gol;
    Dlist<customer> list_pla;
    Dlist<customer> processingList[4]={list_pla, list_gol, list_sil, list_reg};
    int comp_num=0;
    int customer_num;
    int tick=0;
    int busy_dur=0;
    bool isBusy= false;
    //input all the reading
    customer customer_temp;
    cin>>customer_num;

    for (int i = 0; i < customer_num; ++i) {
        cin>>customer_temp.timeStamp>>customer_temp.name>>customer_temp.status>>customer_temp.duration;
        customer *pCus=new customer(customer_temp);
        callList.insertBack(pCus);
    }

    while (comp_num<=customer_num){
        //print out the beginning
        cout<<"Starting tick #"<<tick<<endl;
        if (comp_num==customer_num && tick!=0){break;}
        if (comp_num==0 && customer_num==0){break;}


        //receive the call and put them into different queue
        while (!callList.isEmpty()){
            customer *pCustomer=callList.removeFront();
            if (pCustomer->timeStamp == tick){
                cout << "Call from " << pCustomer->name << " a " << pCustomer->status <<" member "<< endl;
                if (pCustomer->status == "platinum"){processingList[0].insertBack(pCustomer);}
                if (pCustomer->status == "gold"){processingList[1].insertBack(pCustomer);}
                if (pCustomer->status == "silver"){processingList[2].insertBack(pCustomer);}
                if (pCustomer->status == "regular"){processingList[3].insertBack(pCustomer);}
            } else{
                callList.insertFront(pCustomer);
                break;
            }
        }


        //answering the call
        if (!isBusy){
            for (int i=0; i<4; i++) {
                if (!processingList[i].isEmpty()){
                    isBusy= true;
                    customer *np_vic_pro=processingList[i].removeFront();
                    busy_dur=np_vic_pro->duration-1;
                    if (busy_dur==0){comp_num++;}
                    cout<<"Answering call from "<<np_vic_pro->name<<endl;
                    delete np_vic_pro;
                    if (isComplete(processingList) && busy_dur==0){isBusy= false;}
                    break;
                }
            }
        } else{
            busy_dur--;
            if (busy_dur==0) {comp_num++;}
            isBusy= true;
        }

        tick++;
    }
}
